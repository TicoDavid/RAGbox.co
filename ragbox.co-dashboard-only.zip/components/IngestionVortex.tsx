/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useRef, useState } from 'react';

interface IngestionVortexProps {
    onFileDrop: (file: File) => void;
}

const IngestionVortex: React.FC<IngestionVortexProps> = ({ onFileDrop }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const audioRef = useRef<HTMLAudioElement | null>(null);
    const videoRef = useRef<HTMLVideoElement | null>(null);
    
    // UI State for overlay visibility
    const [isDragging, setIsDragging] = useState(false);
    const [isImploding, setIsImploding] = useState(false);

    // Initialize audio ref
    React.useEffect(() => {
        audioRef.current = new Audio("https://storage.googleapis.com/connexusai-assets/sub-bass-short-impact-davies-aguirre-1-00-00.mp3");
        audioRef.current.volume = 0.5;
    }, []);

    // --- Interaction Handlers ---

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            // Trigger Visual Feedback
            setIsImploding(true);
            
            // Play audio
            if (audioRef.current) {
                audioRef.current.currentTime = 0;
                audioRef.current.play().catch(e => console.log("Audio play failed (interaction policy)", e));
            }

            // Play video on drop
            if (videoRef.current) {
                videoRef.current.currentTime = 0;
                videoRef.current.play().catch(e => console.log("Video play failed", e));
            }

            onFileDrop(e.dataTransfer.files[0]);

            // Reset after animation
            setTimeout(() => {
                setIsImploding(false);
            }, 1000);
        }
    };

    return (
        <div 
            ref={containerRef}
            className={`ingestion-vortex-container ${isDragging ? 'dragging' : ''}`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
        >
            <video 
                ref={videoRef}
                src="https://storage.googleapis.com/connexusai-assets/RAGbox%20Vault%20video.mp4"
                className={`vortex-video-element ${isImploding ? 'imploding' : ''}`}
                muted
                playsInline
            />
            
            <div className={`vortex-overlay ${isDragging ? 'active' : ''}`}>
                <div className="vortex-text">
                    <span className="vortex-title">SECURELY UPLOAD</span>
                    <span className="vortex-subtitle">Drag & Drop into the Vault</span>
                </div>
            </div>
        </div>
    );
};

export default IngestionVortex;
