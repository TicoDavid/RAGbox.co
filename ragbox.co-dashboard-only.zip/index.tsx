/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// Vibe coded by ammaar@google.com & Refactored for RAGbox

import { GoogleGenAI } from '@google/genai';
import React, { useState, useCallback, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';

import { Artifact, Session, ComponentVariation, Source, ArtifactType } from './types';
import { generateId, fileToBase64 } from './utils';
import { INITIAL_PLACEHOLDERS } from './constants';

import ArtifactCard from './components/ArtifactCard';
import SideDrawer from './components/SideDrawer';
import IngestionVortex from './components/IngestionVortex';
import { 
    ThinkingIcon, 
    CodeIcon, 
    DesignGenIcon, 
    ArrowUpIcon, 
    GridIcon,
    LockIcon, 
    UnlockIcon, 
    ShieldCheckIcon,
    SaveIcon,
    TrashIcon,
    HistoryIcon,
    PlusIcon,
    ArchiveIcon,
    ChevronDownIcon,
    CopyIcon,
    MaximizeIcon,
    DownloadIcon,
    ImageIcon,
    VideoIcon,
    ChartIcon,
    VisionIcon,
    LayoutIcon,
    SparklesIcon,
    MercuryIcon
} from './components/Icons';

// --- Icons specific to Dashboard ---
const MenuIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>;
const SearchIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>;
const SettingsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.1a2 2 0 0 1-1-1.72v-.51a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>;
const MoonIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>;
const SunIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"/><path d="M12 1v2"/><path d="M12 21v2"/><path d="M4.22 4.22l1.42 1.42"/><path d="M18.36 18.36l1.42 1.42"/><path d="M1 12h2"/><path d="M21 12h2"/><path d="M4.22 19.78l1.42-1.42"/><path d="M18.36 5.64l1.42-1.42"/></svg>;
const FolderIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>;
const PadlockSmallIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>;
const PhotoIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>;
const GlobeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>;

// --- Layout Selector Icons ---
const Layout1Icon = () => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor">
        <rect x="2" y="2" width="10" height="10" rx="2" />
    </svg>
);
const Layout2Icon = () => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor">
        <rect x="1" y="2" width="5" height="10" rx="1" />
        <rect x="8" y="2" width="5" height="10" rx="1" />
    </svg>
);
const Layout4Icon = () => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor">
        <rect x="1" y="1" width="5" height="5" rx="1" />
        <rect x="8" y="1" width="5" height="5" rx="1" />
        <rect x="1" y="8" width="5" height="5" rx="1" />
        <rect x="8" y="8" width="5" height="5" rx="1" />
    </svg>
);

// --- Components ---

function Header({ theme, toggleTheme, searchTerm, onSearchChange }: { 
    theme: 'dark' | 'light', 
    toggleTheme: () => void,
    searchTerm: string,
    onSearchChange: (s: string) => void
}) {
    return (
        <header className="app-header">
            <div className="header-left">
                <div className="logo-container">
                    <img 
                        src="https://storage.googleapis.com/connexusai-assets/Primary_RagBoxCo_Colored_Black.png"
                        alt="RAGbox Logo" 
                        className="ragbox-logo"
                    />
                </div>
                <div className="breadcrumb">
                    <span className="breadcrumb-separator">/</span>
                    <span className="breadcrumb-item">Secure Workspace</span>
                </div>
            </div>
            {/* Global Search Bar */}
            <div className="global-search-container">
                <SearchIcon />
                <input 
                    type="text" 
                    placeholder="Search Vaults & Files..." 
                    value={searchTerm}
                    onChange={(e) => onSearchChange(e.target.value)}
                />
            </div>
            <div className="header-right">
                <button className="header-btn" onClick={toggleTheme}>
                    {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
                </button>
                <button className="header-btn"><SettingsIcon /> Settings</button>
                <video 
                    className="user-avatar-video"
                    src="https://storage.googleapis.com/connexusai-assets/hf_20260124_201326_6aff9253-77b6-48e9-aa38-924d7dbf16eb.mp4"
                    autoPlay
                    loop
                    muted
                    playsInline
                />
            </div>
        </header>
    );
}

// --- Vault & Security Types & Logic ---
type VaultStatus = 'secure' | 'open' | 'closed';
interface Vault {
    id: string;
    name: string;
    status: VaultStatus;
}

// --- INITIAL SYSTEM STATE (CLEAN) ---
const MOCK_VAULTS: Vault[] = []; // Cleared
const VAULT_CONTENTS: Record<string, string> = {}; // Cleared

function VaultPanel({ 
    vaults, 
    onVaultClick,
    onSourceDrop,
    onCreateVault
}: { 
    vaults: Vault[], 
    onVaultClick: (id: string) => void,
    onSourceDrop: (vaultId: string, sourceIds: number[]) => void,
    onCreateVault: () => void
}) {
    const [dragOverVaultId, setDragOverVaultId] = useState<string | null>(null);

    const handleDragOver = (e: React.DragEvent, vault: Vault) => {
        e.preventDefault();
        // Allow dropping into Open vaults (or visually indicate it)
        if (vault.status === 'open') {
            setDragOverVaultId(vault.id);
        }
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        setDragOverVaultId(null);
    };

    const handleDrop = (e: React.DragEvent, vault: Vault) => {
        e.preventDefault();
        setDragOverVaultId(null);
        if (vault.status === 'open') {
            // Check for source transfer payload
            try {
                const data = e.dataTransfer.getData("application/json");
                if (data) {
                    const sources = JSON.parse(data);
                    if (Array.isArray(sources) && sources.length > 0) {
                        const ids = sources.map(s => s.id);
                        onSourceDrop(vault.id, ids);
                    }
                }
            } catch (err) {
                console.error("Drop failed", err);
            }
        }
    };

    const getStatusIcon = (status: VaultStatus) => {
        switch(status) {
            case 'open': return <UnlockIcon />;
            case 'secure': return <LockIcon />;
            case 'closed': return <LockIcon />;
            default: return <LockIcon />;
        }
    };

    return (
        <div className="panel vault-panel">
            <div className="panel-header">
                <h3>Vault Console</h3>
                <button className="icon-btn"><MenuIcon /></button>
            </div>
            <div className="vault-content">
                <button className="add-source-btn" onClick={onCreateVault}><PlusIcon /> Create Vault</button>
                {vaults.map(vault => (
                    <div 
                        key={vault.id} 
                        className={`vault-item ${dragOverVaultId === vault.id ? 'drag-target' : ''}`} 
                        onClick={() => onVaultClick(vault.id)}
                        onDragOver={(e) => handleDragOver(e, vault)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, vault)}
                    >
                        <div className="vault-info">
                            <div className="vault-icon"><FolderIcon /></div>
                            <div className="vault-name">{vault.name}</div>
                        </div>
                        <div className={`vault-status-icon ${vault.status}`}>
                            {getStatusIcon(vault.status)}
                        </div>
                    </div>
                ))}
                {vaults.length === 0 && <div className="empty-filter">System Empty. Initialize new vault.</div>}
            </div>
        </div>
    );
}

// --- PASSWORD SYSTEM ---
const AUTHORIZED_PASSWORDS: string[] = []; // Cleared

function SecurityModal({ 
    isOpen, 
    onClose, 
    vaultName, 
    currentStatus, 
    onUpdateStatus 
}: { 
    isOpen: boolean, 
    onClose: () => void, 
    vaultName: string, 
    currentStatus: VaultStatus, 
    onUpdateStatus: (s: VaultStatus) => void 
}) {
    const [selectedStatus, setSelectedStatus] = useState<VaultStatus>(currentStatus);
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        if(isOpen) {
            setSelectedStatus(currentStatus);
            setPassword('');
            setError('');
        }
    }, [isOpen, currentStatus]);

    const handleAuthenticate = () => {
        // If system is fresh (no passwords set), allow any non-empty input or just allow access
        if (AUTHORIZED_PASSWORDS.length === 0) {
            onUpdateStatus(selectedStatus);
            onClose();
            return;
        }

        if (AUTHORIZED_PASSWORDS.includes(password)) {
            onUpdateStatus(selectedStatus);
            onClose();
        } else {
            setError('Access Denied: Invalid Credentials');
            // Shake effect or clear could go here
        }
    };

    if (!isOpen) return null;

    return (
        <div className="security-modal-overlay" onClick={onClose}>
            <div className="security-modal" onClick={e => e.stopPropagation()}>
                <div className="security-header">
                    <div className="security-shield"><ShieldCheckIcon /></div>
                    <h2>Vault Access Control</h2>
                    <p>Manage security protocol for <strong>{vaultName}</strong></p>
                </div>
                
                <div className="status-selector">
                    <button 
                        className={`status-btn ${selectedStatus === 'secure' ? 'active secure' : ''}`}
                        onClick={() => setSelectedStatus('secure')}
                    >
                        SECURE
                    </button>
                    <button 
                        className={`status-btn ${selectedStatus === 'open' ? 'active open' : ''}`}
                        onClick={() => setSelectedStatus('open')}
                    >
                        OPEN
                    </button>
                    <button 
                        className={`status-btn ${selectedStatus === 'closed' ? 'active closed' : ''}`}
                        onClick={() => setSelectedStatus('closed')}
                    >
                        CLOSE
                    </button>
                </div>

                <div className="security-form">
                    <input 
                        type="password" 
                        placeholder={AUTHORIZED_PASSWORDS.length === 0 ? "Set Session Password (Optional)" : "Enter Vault Password"}
                        className={`security-input ${error ? 'error' : ''}`}
                        value={password}
                        onChange={e => {
                            setPassword(e.target.value);
                            setError('');
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && handleAuthenticate()}
                    />
                    {error && <div className="security-error-msg">{error}</div>}
                    <button 
                        className="security-action-btn"
                        onClick={handleAuthenticate}
                    >
                        Authenticate & Update
                    </button>
                </div>
            </div>
        </div>
    );
}

function SaveToVaultModal({ 
    isOpen, 
    onClose, 
    vaults, 
    onSave 
}: { 
    isOpen: boolean, 
    onClose: () => void, 
    vaults: Vault[], 
    onSave: (vaultId: string) => void 
}) {
    const [selectedVaultId, setSelectedVaultId] = useState<string | null>(null);

    if (!isOpen) return null;

    return (
        <div className="security-modal-overlay" onClick={onClose}>
            <div className="security-modal" onClick={e => e.stopPropagation()} style={{ width: '500px' }}>
                <div className="security-header">
                    <div className="security-shield" style={{ color: '#0000FF' }}><ArchiveIcon /></div>
                    <h2>Save Session to Vault</h2>
                    <p>Select an <strong>Open Vault</strong> to permit data ingress.</p>
                </div>
                
                <div className="vault-content" style={{ maxHeight: '300px', border: '1px solid var(--border-color)', borderRadius: '8px', padding: '8px', background: 'var(--bg-app)' }}>
                    {vaults.map(vault => {
                        const isLocked = vault.status !== 'open';
                        return (
                            <div 
                                key={vault.id} 
                                className={`vault-item ${selectedVaultId === vault.id ? 'drag-target' : ''}`}
                                style={{ 
                                    opacity: isLocked ? 0.5 : 1, 
                                    cursor: isLocked ? 'not-allowed' : 'pointer',
                                    marginBottom: '8px'
                                }}
                                onClick={() => !isLocked && setSelectedVaultId(vault.id)}
                            >
                                <div className="vault-info">
                                    <div className="vault-icon"><FolderIcon /></div>
                                    <div className="vault-name">{vault.name} {isLocked && "(LOCKED)"}</div>
                                </div>
                                <div className={`vault-status-icon ${vault.status}`}>
                                    {isLocked ? <LockIcon /> : <UnlockIcon />}
                                </div>
                            </div>
                        );
                    })}
                    {vaults.length === 0 && <div style={{padding: 10, textAlign:'center', color:'#666'}}>No vaults found. Create one first.</div>}
                </div>

                <div className="security-form">
                    <button 
                        className="security-action-btn"
                        disabled={!selectedVaultId}
                        style={{ opacity: !selectedVaultId ? 0.5 : 1, background: '#0000FF' }}
                        onClick={() => {
                            if (selectedVaultId) {
                                onSave(selectedVaultId);
                                onClose();
                            }
                        }}
                    >
                        Confirm Transfer
                    </button>
                </div>
            </div>
        </div>
    );
}

// Initial Sources
const INITIAL_SOURCES: Source[] = [];

function RagBoxPanel({ sources, onFileDrop }: { 
    sources: Source[], 
    onFileDrop: (f: File) => void
}) {
    const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

    const handleDragStart = (e: React.DragEvent, source: Source) => {
        // If the item being dragged is NOT in the current selection, 
        // treat it as a single drag action for just that item.
        // Otherwise, drag all selected items.
        
        let itemsToDrag = [];
        
        if (selectedIds.has(source.id)) {
             itemsToDrag = sources.filter(s => selectedIds.has(s.id));
        } else {
             itemsToDrag = [source];
             // Optional: Update visual selection to match drag
             // setSelectedIds(new Set([source.id]));
        }
        
        e.dataTransfer.setData("application/json", JSON.stringify(itemsToDrag));
    };

    const toggleSelection = (id: number) => {
        const newSet = new Set(selectedIds);
        if (newSet.has(id)) {
            newSet.delete(id);
        } else {
            newSet.add(id);
        }
        setSelectedIds(newSet);
    };

    return (
        <div className="panel sources-panel">
            <div className="panel-header">
                <h3>Security Drop</h3>
                <button className="icon-btn"><MenuIcon /></button>
            </div>
            <IngestionVortex onFileDrop={onFileDrop} />
            <div className="sources-content">
                {sources.length === 0 && (
                    <div style={{ padding: '20px', textAlign: 'center', color: 'var(--text-tertiary)', fontSize: '0.8rem' }}>
                        No active sources. Drop files above.
                    </div>
                )}
                <div className="sources-list">
                    {sources.map(source => {
                        const isSelected = selectedIds.has(source.id);
                        return (
                            <div 
                                key={source.id} 
                                className={`source-card-new ${source.isNew ? 'glow' : ''} ${isSelected ? 'selected' : ''}`}
                                draggable={true} // Always allow drag
                                onDragStart={(e) => handleDragStart(e, source)}
                                onClick={() => toggleSelection(source.id)}
                            >
                                <div className="source-card-icon">
                                    {source.type === 'image' ? <PhotoIcon /> : <PadlockSmallIcon />}
                                </div>
                                <div className="source-card-details">
                                    <div className="source-card-title">{source.title}</div>
                                    <div className="source-card-time">{source.time}</div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}

// --- CONTEXT BAR (NEW) ---
function ContextBar({ vaults, sources }: { vaults: Vault[], sources: Source[] }) {
    const [isExpanded, setIsExpanded] = useState(false);
    
    const openVaults = vaults.filter(v => v.status === 'open');
    const hasContext = openVaults.length > 0 || sources.length > 0;
    
    return (
        <div className={`context-bar ${hasContext ? 'active' : ''}`}>
             <div className="context-header" onClick={() => hasContext && setIsExpanded(!isExpanded)}>
                 <span className="context-label">
                    {hasContext ? 'Active Context' : 'Active Context: No verified sources selected'}
                 </span>
                 {hasContext && (
                     <div className="context-summary">
                        {openVaults.length > 0 && <span>{openVaults.length} Vaults</span>}
                        {openVaults.length > 0 && sources.length > 0 && <span className="separator">•</span>}
                        {sources.length > 0 && <span>{sources.length} Sources</span>}
                        <span className={`chevron ${isExpanded ? 'expanded' : ''}`}><ChevronDownIcon /></span>
                     </div>
                 )}
             </div>
             {hasContext && isExpanded && (
                 <div className="context-details">
                     {openVaults.map(v => (
                         <div key={v.id} className="context-item vault">
                             <span className="dot"></span> {v.name}
                         </div>
                     ))}
                     {sources.map(s => (
                         <div key={s.id} className="context-item source">
                             <span className="dot"></span> {s.title}
                         </div>
                     ))}
                 </div>
             )}
        </div>
    );
}

// Helper to highlight citations in text
const renderTextWithCitations = (text: string) => {
    const parts = text.split(/(\[Document:.*?\])/g);
    return parts.map((part, index) => {
        if (part.startsWith('[Document:') && part.endsWith(']')) {
            return <span key={index} className="citation-badge">{part}</span>;
        }
        return part;
    });
};

interface ChatMessageProps { 
    text: string; 
    isUser: boolean; 
    timestamp: number;
    groundingMetadata?: any; // For Google Search Results
}

const ChatMessage: React.FC<ChatMessageProps> = ({ text, isUser, timestamp, groundingMetadata }) => {
    if (isUser) {
        return (
            <div className="chat-message user">
                <span className="chat-label user">YOU</span>
                <div className="chat-text">{text}</div>
            </div>
        );
    }
    
    // Check for "Withheld" state based on specific system phrasing
    const isWithheld = text.includes("We cannot verify a response from the selected sources");
    if (isWithheld) {
        return (
             <div className="chat-message mercury">
                 <span className="chat-label mercury">MERCURY</span>
                 <div className="mercury-withheld">
                     {text.replace('MERCURY', '').trim()}
                 </div>
             </div>
        );
    }

    const lines = text.split('\n');
    const sections: React.ReactNode[] = [];
    let currentSectionTitle: string | null = null;
    let currentSectionContent: React.ReactNode[] = [];

    const flushSection = () => {
        if (currentSectionTitle || currentSectionContent.length > 0) {
            // Check if title is FINDINGS to add green class
            const isFindings = currentSectionTitle?.toUpperCase() === 'FINDINGS';
            sections.push(
                <div key={sections.length} className="mercury-section">
                    {currentSectionTitle && (
                        <div className={`mercury-section-header ${isFindings ? 'green-mode' : ''}`}>
                            {currentSectionTitle}
                        </div>
                    )}
                    <div className="mercury-section-content">{currentSectionContent}</div>
                </div>
            );
        }
        currentSectionTitle = null;
        currentSectionContent = [];
    };

    lines.forEach((line, i) => {
        const trimmed = line.trim();
        if (!trimmed) return;
        if (trimmed === 'MERCURY') return;
        if (trimmed.match(/^(Summary|Findings|Sources)$/i)) {
            flushSection();
            currentSectionTitle = trimmed.toUpperCase();
        } else if (trimmed.startsWith('•') || trimmed.startsWith('-')) {
             currentSectionContent.push(
                 <div key={i} className="mercury-list-item">
                     {renderTextWithCitations(trimmed.substring(1).trim())}
                 </div>
             );
        } else {
            currentSectionContent.push(
                <p key={i} className="mercury-paragraph">
                    {renderTextWithCitations(trimmed)}
                </p>
            );
        }
    });
    flushSection();

    // Grounding Sources (Google Search)
    let groundingSources = null;
    if (groundingMetadata?.groundingChunks) {
        groundingSources = (
            <div className="grounding-sources">
                 <div className="mercury-section-header"><GlobeIcon /> Verified Web Sources</div>
                 <div className="grounding-chips">
                     {groundingMetadata.groundingChunks.map((chunk: any, i: number) => {
                         if (chunk.web) {
                             return (
                                 <a key={i} href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="grounding-chip">
                                     {chunk.web.title || "Web Source"}
                                 </a>
                             )
                         }
                         return null;
                     })}
                 </div>
            </div>
        );
    }

    return (
        <div className="chat-message mercury">
            <span className="chat-label mercury">MERCURY</span>
            <div className="mercury-content">
                {sections}
                {groundingSources}
                {/* Verified Response Actions */}
                <div className="response-actions">
                    <button className="response-action-btn" title="Copy to Studio"><CopyIcon /> Copy to Studio</button>
                    <button className="response-action-btn" title="Expand Analysis"><MaximizeIcon /> Expand</button>
                    <button className="response-action-btn" title="Export Findings"><DownloadIcon /> Export</button>
                </div>
            </div>
        </div>
    );
};

// --- MERCURY SYSTEM INTELLIGENCE (UPDATED) ---
const MERCURY_SYSTEM_INSTRUCTION = `
You are Mercury, an evidence-bound intelligence system operating inside a secure, sovereign document environment.
Your purpose is to provide verified, citation-backed intelligence derived exclusively from the user’s authorized documents and vaults.

IF Google Search is enabled:
- Use it to verify external claims or retrieve specific URL context requested by the user.
- Integrate these web findings into your 'Findings' section, citing them clearly.

You MUST follow these rules at all times:
1. EVIDENCE-ONLY RESPONSES
- You may ONLY generate statements that can be directly verified from the active document context OR Google Search results.
- Every factual claim MUST be supported by one or more citations.
2. WITHHOLDING LOGIC (NO HALLUCINATION)
- If you cannot confidently verify a response from the selected sources, you MUST NOT speculate, infer, or guess.
- In such cases, respond ONLY with:
  “We cannot verify a response from the selected sources.”
3. STRUCTURED OUTPUT FORMAT
When a verified response is possible, format your output EXACTLY as follows:
MERCURY
Summary
• A concise, high-level conclusion based strictly on verified findings.
Findings
• Bullet-pointed factual findings.
Sources
• List each source document used.
`.trim();

// --- INITIAL LOGIC (UPDATED) ---
const getInitialChatLog = (vaults: Vault[], sources: any[]) => {
    const openVaults = vaults.filter(v => v.status === 'open');
    const hasSources = sources.length > 0;
    
    let text = "MERCURY\n\nSUMMARY\n• Secure Core Online.\n";
    
    if (openVaults.length === 0 && !hasSources) {
        text += "• No active vault context detected.";
    } else {
        text += "• Active context verified and ready for analysis.";
    }
    return [{ id: 'intro', text, isUser: false, timestamp: Date.now() }];
};

// --- STUDIO TYPES ---
type StudioMode = 'UI' | 'ASSET' | 'CHART' | 'VISION' | 'VIDEO';

function App() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [inputValue, setInputValue] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');
  
  // Vault State - INITIALIZED EMPTY
  const [vaults, setVaults] = useState<Vault[]>(MOCK_VAULTS);
  const [editingVaultId, setEditingVaultId] = useState<string | null>(null);

  // Sources State (RAGbox)
  const [sources, setSources] = useState<Source[]>(INITIAL_SOURCES);

  // Layout State (Resizable Panels)
  // We track widths for Vault(0), Sources(1), Chat(2). Studio(3) is flex 1fr.
  const [colWidths, setColWidths] = useState([280, 280, 450]);
  const isResizing = useRef<number | null>(null);

  // Studio Grid Layout State
  const [gridColumns, setGridColumns] = useState<1 | 2 | 4>(2);
  const [studioMode, setStudioMode] = useState<StudioMode>('UI');

  // RAGbox Layout State
  const [chatLog, setChatLog] = useState<{id: string, text: string, isUser: boolean, timestamp: number, groundingMetadata?: any}[]>(() => getInitialChatLog(MOCK_VAULTS, INITIAL_SOURCES));
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [focusedArtifactIndex, setFocusedArtifactIndex] = useState<number | null>(null);

  // Session & Archive State
  const [archivedSessions, setArchivedSessions] = useState<Session[]>([]);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);

  // Drawer State for variations/code/history
  const [drawerState, setDrawerState] = useState<{
      isOpen: boolean;
      mode: 'code' | 'variations' | 'history' | null;
      title: string;
      data: any; 
  }>({ isOpen: false, mode: null, title: '', data: null });
  const [componentVariations, setComponentVariations] = useState<ComponentVariation[]>([]);

  const chatScrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
      document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
      if (chatScrollRef.current) {
          chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
      }
  }, [chatLog]);

  // --- Resizing Logic ---
  const handleMouseDown = (index: number) => {
      isResizing.current = index;
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = 'col-resize';
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
      if (isResizing.current === null) return;
      const index = isResizing.current;
      
      setColWidths(prev => {
          const newWidths = [...prev];
          // Simple logic: update width based on mouse X. 
          if (e.movementX) {
              newWidths[index] = Math.max(150, newWidths[index] + e.movementX);
          }
          return newWidths;
      });
  }, []);

  const handleMouseUp = () => {
      isResizing.current = null;
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = '';
  };

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(event.target.value);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter' && !isLoading) {
      event.preventDefault();
      handleSendMessage('chat');
    }
  };

  const handleFileDrop = async (file: File) => {
        // Detect type
        let typeDescription = "Text Document";
        let isImage = false;

        if (file.type.startsWith('image/')) {
            typeDescription = "Visual Asset";
            isImage = true;
        } else if (file.type.startsWith('audio/')) {
            typeDescription = "Audio Record";
        } else if (file.type.startsWith('video/')) {
            typeDescription = "Video Footage";
        } else if (file.type.includes('pdf')) {
            typeDescription = "PDF Document";
        }

        let content = '';
        let base64 = undefined;

        if (isImage) {
            try {
                base64 = await fileToBase64(file);
                content = `[Image Asset: ${file.name}]`;
            } catch (e) {
                console.error("Failed to read image", e);
                return;
            }
        } else {
             content = `[Document: ${file.name}]
- Status: Uploaded via Security Drop.
- Analysis: Contains verified data regarding user inquiry.
- Key Metric: 98% compliance with internal standards.
- Note: This is a simulated ingestion for the demo.`;
        }

        const newSource: Source = {
            id: Date.now(),
            title: file.name,
            type: isImage ? 'image' : 'text',
            time: "Just now",
            isNew: true,
            content: content,
            base64: base64,
            mimeType: file.type
        };

        setTimeout(() => {
            setSources(prev => [newSource, ...prev]);
             setChatLog(prev => [...prev, { 
                id: generateId(), 
                text: `MERCURY\n\nFINDINGS\n• New Source Ingested: "${file.name}"\n• Type: ${typeDescription}`, 
                isUser: false, 
                timestamp: Date.now() 
            }]);
            
            // Auto-switch to Vision mode if image dropped
            if (isImage) setStudioMode('VISION');
        }, 800); 
  };

  const parseJsonStream = async function* (responseStream: AsyncGenerator<{ text: string }>) {
      let buffer = '';
      for await (const chunk of responseStream) {
          const text = chunk.text;
          if (typeof text !== 'string') continue;
          buffer += text;
          let braceCount = 0;
          let start = buffer.indexOf('{');
          while (start !== -1) {
              braceCount = 0;
              let end = -1;
              for (let i = start; i < buffer.length; i++) {
                  if (buffer[i] === '{') braceCount++;
                  else if (buffer[i] === '}') braceCount--;
                  if (braceCount === 0 && i > start) {
                      end = i;
                      break;
                  }
              }
              if (end !== -1) {
                  const jsonString = buffer.substring(start, end + 1);
                  try {
                      yield JSON.parse(jsonString);
                      buffer = buffer.substring(end + 1);
                      start = buffer.indexOf('{');
                  } catch (e) {
                      start = buffer.indexOf('{', start + 1);
                  }
              } else {
                  break; 
              }
          }
      }
  };

  const handleGenerateVariations = useCallback(async (artifactId: string) => {
    const artifact = artifacts.find(a => a.id === artifactId);
    if (!artifact) return;

    setIsLoading(true);
    setComponentVariations([]);
    setDrawerState({ isOpen: true, mode: 'variations', title: 'Variations', data: artifactId });

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `You are a master UI/UX designer. Generate 3 RADICAL CONCEPTUAL VARIATIONS of the component in strict JSON. **STRICT IP SAFEGUARD:** No names of artists. Use physical and material metaphors. Required JSON Output Format (stream ONE object per line): \`{ "name": "Persona Name", "html": "..." }\``;

        const responseStream = await ai.models.generateContentStream({
            model: 'gemini-3-flash-preview',
             contents: [{ parts: [{ text: prompt }], role: 'user' }],
             config: { temperature: 1.2 }
        });

        for await (const variation of parseJsonStream(responseStream)) {
            if (variation.name && variation.html) {
                setComponentVariations(prev => [...prev, variation]);
            }
        }
    } catch (e: any) {
        console.error("Error generating variations:", e);
    } finally {
        setIsLoading(false);
    }
  }, [artifacts]);

  const applyVariation = (html: string) => {
      setDrawerState(s => ({ ...s, isOpen: false }));
  };

  const handleSendMessage = useCallback(async (mode: 'chat' | 'design' = 'chat', overridePrompt?: string) => {
    const textToUse = overridePrompt || inputValue.trim();
    if (!textToUse || isLoading) return;

    if (!overridePrompt) setInputValue('');
    setIsLoading(true);
    
    // 1. Add User Message
    const userMsgId = generateId();
    setChatLog(prev => [...prev, { id: userMsgId, text: textToUse, isUser: true, timestamp: Date.now() }]);

    // 2. Setup parallel promises
    const promises: Promise<void>[] = [];
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    // --- CONTEXT BUILDER ---
    let dynamicContext = "SECURE DOCUMENT INDEX (DYNAMIC):\n\n";
    let hasContext = false;
    let imageContext: Source | undefined = undefined;

    if (sources.length > 0) {
        sources.forEach(s => {
            if (s.type === 'image') imageContext = s; // Grab last image for Vision mode
            if (s.content) {
                dynamicContext += `${s.content}\n\n`;
                hasContext = true;
            }
        });
    }

    vaults.forEach(v => {
        if (v.status === 'open' && VAULT_CONTENTS[v.id]) {
            dynamicContext += `${VAULT_CONTENTS[v.id]}\n\n`;
            hasContext = true;
        }
    });

    if (!hasContext) {
        dynamicContext += "NO DOCUMENTS AVAILABLE. USER MUST OPEN VAULT OR DROP FILES.";
    }

    // --- PROCESS A: MERCURY CHAT RESPONSE (ALWAYS RUNS) ---
    const mercuryPromise = (async () => {
        const botMsgId = generateId();
        setChatLog(prev => [...prev, { id: botMsgId, text: '', isUser: false, timestamp: Date.now() }]);

        try {
            // Enable Google Search for grounding URLs
            const chatStream = await ai.models.generateContentStream({
                model: 'gemini-3-flash-preview',
                contents: [
                    { role: 'user', parts: [{ text: `Active Context:\n${dynamicContext}\n\nUser Query: ${textToUse}` }] }
                ],
                config: {
                    systemInstruction: MERCURY_SYSTEM_INSTRUCTION,
                    temperature: 0.2, // Precise, factual
                    tools: [{ googleSearch: {} }] // Enable Grounding/Scraping
                }
            });

            let fullText = '';
            for await (const chunk of chatStream) {
                const text = chunk.text;
                if (text) {
                    fullText += text;
                    // Update log with text AND grounding metadata if present
                    setChatLog(prev => prev.map(msg => 
                        msg.id === botMsgId ? { 
                            ...msg, 
                            text: fullText, 
                            groundingMetadata: chunk.candidates?.[0]?.groundingMetadata 
                        } : msg
                    ));
                }
            }
        } catch (e) {
             setChatLog(prev => prev.map(msg => 
                msg.id === botMsgId ? { ...msg, text: "We cannot verify a response from the selected sources. System connection interrupted." } : msg
            ));
        }
    })();
    promises.push(mercuryPromise);


    // --- PROCESS B: STUDIO ARTIFACT GENERATION (ONLY IF DESIGN MODE) ---
    if (mode === 'design') {
        const studioPromise = (async () => {
            try {
                const sessionId = generateId();
                const artifactType: ArtifactType = 
                    studioMode === 'VIDEO' ? 'video' : 
                    studioMode === 'ASSET' ? 'image' : 
                    studioMode === 'CHART' ? 'chart' : 'ui';

                // Initial Placeholder
                const placeholderId = `${sessionId}_0`;
                const placeholderArtifact: Artifact = {
                    id: placeholderId,
                    type: artifactType,
                    styleName: `Generating ${studioMode}...`,
                    title: textToUse,
                    content: '',
                    status: 'generating',
                };
                setArtifacts(prev => [placeholderArtifact, ...prev]);

                // --- MODE SWITCH ---
                
                // 1. ASSET MODE (IMAGEN)
                if (studioMode === 'ASSET') {
                    const response = await ai.models.generateImages({
                        model: 'imagen-4.0-generate-001',
                        prompt: textToUse,
                        config: { numberOfImages: 1 }
                    });
                    const b64 = response.generatedImages?.[0]?.image?.imageBytes;
                    if (b64) {
                        setArtifacts(prev => prev.map(a => 
                            a.id === placeholderId ? { ...a, content: b64, status: 'complete', styleName: 'Asset Fabricator' } : a
                        ));
                    }
                }
                
                // 2. VIDEO MODE (VEO)
                else if (studioMode === 'VIDEO') {
                    // Check API Key
                    if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
                         const veoAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
                         let operation = await veoAi.models.generateVideos({
                             model: 'veo-3.1-fast-generate-preview',
                             prompt: textToUse,
                             config: { numberOfVideos: 1 }
                         });
                         
                         // Poll for completion (Assuming helper would be used, implementing inline to avoid missing helper)
                         // NOTE: Reusing the conceptual polling logic
                         while (!operation.done) {
                             await new Promise(resolve => setTimeout(resolve, 5000));
                             operation = await veoAi.operations.getVideosOperation({name: operation.name});
                         }
                         
                         const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
                         if (videoUri) {
                             setArtifacts(prev => prev.map(a => 
                                a.id === placeholderId ? { ...a, content: `${videoUri}&key=${process.env.API_KEY}`, status: 'complete', styleName: 'Motion Brief' } : a
                             ));
                         }

                    } else {
                        if (window.aistudio) await window.aistudio.openSelectKey();
                         setArtifacts(prev => prev.map(a => 
                            a.id === placeholderId ? { ...a, status: 'error', styleName: 'Auth Required' } : a
                        ));
                    }
                }

                // 3. CHART MODE (SVG/Viz)
                else if (studioMode === 'CHART') {
                    const prompt = `You are a data visualization expert. Create a raw SVG chart representing the following data request: "${textToUse}". Use a dark theme palette (background #000, accents #2563EB, #06b6d4). Return ONLY the raw <svg>...</svg> code. No markdown.`;
                     const response = await ai.models.generateContent({
                        model: 'gemini-3-flash-preview',
                        contents: [{ parts: [{ text: prompt }], role: 'user' }]
                    });
                    
                    let svg = response.text || '';
                    if (svg.startsWith('```')) svg = svg.replace(/```(xml|svg)?/g, '').trim();
                    
                    setArtifacts(prev => prev.map(a => 
                        a.id === placeholderId ? { ...a, content: svg, status: 'complete', styleName: 'Mercury Visualizer' } : a
                    ));
                }

                // 4. VISION MODE (Wireframe to High-Fi)
                else if (studioMode === 'VISION') {
                     if (!imageContext?.base64) {
                         // No image? Fallback to standard UI gen
                         setStudioMode('UI');
                         throw new Error("No reference image found. Dropping to standard UI mode.");
                     }
                     
                     const prompt = `You are a frontend expert. Convert this wireframe/sketch into a high-fidelity, stunning HTML/CSS component. Dark mode, executive style. Return ONLY raw HTML.`;
                     
                     const responseStream = await ai.models.generateContentStream({
                        model: 'gemini-3-flash-preview',
                        contents: [{ 
                            role: 'user', 
                            parts: [
                                { inlineData: { mimeType: imageContext.mimeType || 'image/png', data: imageContext.base64 } },
                                { text: prompt }
                            ]
                        }]
                    });

                    let accumulatedHtml = '';
                    for await (const chunk of responseStream) {
                        const text = chunk.text;
                        if (typeof text === 'string') {
                            accumulatedHtml += text;
                            setArtifacts(prev => prev.map(a => 
                                a.id === placeholderId ? { ...a, content: accumulatedHtml, status: 'streaming' } : a
                            ));
                        }
                    }
                    setArtifacts(prev => prev.map(a => 
                        a.id === placeholderId ? { ...a, status: 'complete', styleName: 'Vision-to-UI' } : a
                    ));
                }

                // 5. STANDARD UI MODE (Default)
                else {
                    // Existing UI Logic
                    const styleResponse = await ai.models.generateContent({
                        model: 'gemini-3-flash-preview',
                        contents: { role: 'user', parts: [{ text: `Generate 1 creative style name for: "${textToUse}". JSON array: ["Name"]` }] }
                    });
                    
                    let styleName = "Modern UI";
                    try {
                        const jsonMatch = styleResponse.text?.match(/\[.*\]/);
                        if (jsonMatch) styleName = JSON.parse(jsonMatch[0])[0];
                    } catch (e) {}
                    
                    setArtifacts(prev => prev.map(a => 
                        a.id === placeholderId ? { ...a, styleName } : a
                    ));

                    const prompt = `You are RAGbox AI. Create a stunning UI component for: "${textToUse}". Style: ${styleName}. Return ONLY RAW HTML. No markdown fences.`;
                    const responseStream = await ai.models.generateContentStream({
                        model: 'gemini-3-flash-preview',
                        contents: [{ parts: [{ text: prompt }], role: "user" }],
                    });

                    let accumulatedHtml = '';
                    for await (const chunk of responseStream) {
                        const text = chunk.text;
                        if (typeof text === 'string') {
                            accumulatedHtml += text;
                            setArtifacts(prev => prev.map(a => 
                                a.id === placeholderId ? { ...a, content: accumulatedHtml, status: 'streaming' } : a
                            ));
                        }
                    }
                     setArtifacts(prev => prev.map(a => 
                        a.id === placeholderId ? { ...a, status: 'complete' } : a
                    ));
                }

            } catch (e) {
                console.error("Studio generation failed", e);
                setArtifacts(prev => prev.map(a => a.status === 'generating' || a.status === 'streaming' ? { ...a, status: 'error' } : a));
            }
        })();
        promises.push(studioPromise);
    }

    await Promise.all(promises);
    setIsLoading(false);

  }, [inputValue, isLoading, sources, vaults, studioMode]);

  // --- FILTERING LOGIC ---
  const filteredVaults = vaults.filter(v => v.name.toLowerCase().includes(globalSearchTerm.toLowerCase()));
  const filteredSources = sources.filter(s => s.title.toLowerCase().includes(globalSearchTerm.toLowerCase()));


  // --- SESSION ACTIONS ---

  const handleNewSession = () => {
      if (chatLog.length > 1 || artifacts.length > 0) {
          const sessionTitle = chatLog.find(m => m.isUser)?.text || `Session ${new Date().toLocaleTimeString()}`;
          const session: Session = {
              id: generateId(),
              prompt: sessionTitle,
              timestamp: Date.now(),
              artifacts: [...artifacts] 
          };
          setArchivedSessions(prev => [session, ...prev]);
      }
      setChatLog(getInitialChatLog(vaults, sources));
      setArtifacts([]);
  };

  const handleDeleteSession = () => {
      // Direct clean out as requested (Removed confirm dialog for immediate action)
      setChatLog(getInitialChatLog(vaults, sources));
      setArtifacts([]);
  };

  const handleCreateVault = () => {
      const name = prompt("Enter Vault Name:");
      if (name) {
          const newVault: Vault = {
              id: generateId(),
              name: name,
              status: 'open'
          };
          setVaults(prev => [...prev, newVault]);
          setChatLog(prev => [...prev, {
              id: generateId(),
              text: `MERCURY\n\nFINDINGS\n• New Secure Vault Initialized: "${name}"\n• Status: OPEN (Ready for ingress)`,
              isUser: false,
              timestamp: Date.now()
          }]);
      }
  };

  const handleMoveSourceToVault = (vaultId: string, sourceIds: number[]) => {
      const targetVault = vaults.find(v => v.id === vaultId);
      if (!targetVault) return;

      const sourcesToMove = sources.filter(s => sourceIds.includes(s.id));
      if (sourcesToMove.length === 0) return;

      // Add to vault content (simulated)
      let appendContent = "";
      sourcesToMove.forEach(s => {
          appendContent += `\n[Moved Source: ${s.title}]\n${s.content || '(Binary Data)'}`;
      });
      
      if (VAULT_CONTENTS[vaultId]) {
          VAULT_CONTENTS[vaultId] += appendContent;
      } else {
          VAULT_CONTENTS[vaultId] = appendContent;
      }

      // Remove from sources list
      setSources(prev => prev.filter(s => !sourceIds.includes(s.id)));

      // Feedback Log
      setChatLog(prev => [...prev, {
          id: generateId(),
          text: `MERCURY\n\nFINDINGS\n• Secure Transfer: ${sourcesToMove.length} item(s) moved to "${targetVault.name}".\n• Security Drop cleared.`,
          isUser: false,
          timestamp: Date.now()
      }]);
  };

  const handleSaveToVault = (vaultId: string) => {
      const vaultName = vaults.find(v => v.id === vaultId)?.name;
      const sessionData = chatLog.map(c => `${c.isUser ? 'USER' : 'MERCURY'}: ${c.text}`).join('\n');
      const artifactData = artifacts.map(a => `[Artifact: ${a.styleName}]`).join('\n');
      
      if (VAULT_CONTENTS[vaultId]) {
          VAULT_CONTENTS[vaultId] += `\n\n[SAVED SESSION - ${new Date().toLocaleDateString()}]\n${sessionData}\n${artifactData}`;
      }
      const sessionTitle = chatLog.find(m => m.isUser)?.text || `Saved Session`;
      const session: Session = {
          id: generateId(),
          prompt: `SAVED: ${sessionTitle}`,
          timestamp: Date.now(),
          artifacts: [...artifacts]
      };
      setArchivedSessions(prev => [session, ...prev]);
      setChatLog([{ 
          id: generateId(), 
          text: `MERCURY\n\nSUMMARY\n• Session successfully encrypted and transferred to vault: "${vaultName}".\n• Workspace cleared for new tasks.`, 
          isUser: false, 
          timestamp: Date.now() 
      }]);
      setArtifacts([]);
  };

  return (
    <>
        <SideDrawer 
            isOpen={drawerState.isOpen} 
            onClose={() => setDrawerState(s => ({...s, isOpen: false}))} 
            title={drawerState.title}
        >
            {/* Drawer Content... */}
             {drawerState.mode === 'code' && (
                <pre className="code-block"><code>{drawerState.data}</code></pre>
            )}
            
            {drawerState.mode === 'variations' && (
                <div className="sexy-grid">
                    {componentVariations.map((v, i) => (
                         <div key={i} className="sexy-card" onClick={() => applyVariation(v.html)}>
                             <div className="sexy-preview">
                                 <iframe srcDoc={v.html} title={v.name} sandbox="allow-scripts allow-same-origin" />
                             </div>
                             <div className="sexy-label">{v.name}</div>
                         </div>
                    ))}
                    {componentVariations.length === 0 && (
                        <div className="loading-state"><ThinkingIcon /> Designing...</div>
                    )}
                </div>
            )}

            {drawerState.mode === 'history' && (
                <div className="sources-list">
                    {archivedSessions.length === 0 && <div style={{padding: 20, color: '#666'}}>No archived sessions.</div>}
                    {archivedSessions.map(session => (
                        <div key={session.id} className="source-card-new">
                            <div className="source-card-icon"><HistoryIcon /></div>
                            <div className="source-card-details">
                                <div className="source-card-title">{session.prompt}</div>
                                <div className="source-card-time">{new Date(session.timestamp).toLocaleString()}</div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </SideDrawer>

        <SecurityModal 
            isOpen={!!editingVaultId}
            onClose={() => setEditingVaultId(null)}
            vaultName={vaults.find(v => v.id === editingVaultId)?.name || 'Unknown Vault'}
            currentStatus={vaults.find(v => v.id === editingVaultId)?.status || 'closed'}
            onUpdateStatus={(newStatus) => {
                if(editingVaultId) {
                    setVaults(prev => prev.map(v => v.id === editingVaultId ? { ...v, status: newStatus } : v));
                    if(newStatus === 'open') {
                        setChatLog(prev => [...prev, { 
                            id: generateId(), 
                            text: `MERCURY\n\nFindings\n• Vault "${vaults.find(v => v.id === editingVaultId)?.name}" access granted.\n• Context updated.`, 
                            isUser: false, 
                            timestamp: Date.now() 
                        }]);
                    }
                }
            }}
        />

        <SaveToVaultModal 
            isOpen={isSaveModalOpen}
            onClose={() => setIsSaveModalOpen(false)}
            vaults={vaults}
            onSave={handleSaveToVault}
        />

        <div className="ragbox-app">
            <Header 
                theme={theme} 
                toggleTheme={toggleTheme} 
                searchTerm={globalSearchTerm}
                onSearchChange={setGlobalSearchTerm}
            />
            
            {/* Dynamic Resizable Layout */}
            <div 
                className="ragbox-layout"
                style={{
                    gridTemplateColumns: `${colWidths[0]}px 16px ${colWidths[1]}px 16px ${colWidths[2]}px 16px 1fr`
                }}
            >
                {/* COLUMN 0: THE VAULT */}
                <VaultPanel 
                    vaults={filteredVaults} 
                    onVaultClick={setEditingVaultId} 
                    onSourceDrop={handleMoveSourceToVault}
                    onCreateVault={handleCreateVault}
                />
                <div className="resizer" onMouseDown={() => handleMouseDown(0)}></div>

                {/* COLUMN 1: RAG.box (Sources) */}
                <RagBoxPanel 
                    sources={filteredSources} 
                    onFileDrop={handleFileDrop} 
                />
                <div className="resizer" onMouseDown={() => handleMouseDown(1)}></div>

                {/* COLUMN 2: CHAT */}
                <div className="panel chat-panel">
                    <div className="panel-header">
                        <div style={{display:'flex', gap: 12, alignItems:'center'}}>
                            <h3 className="mercury-logo-text">Mercury</h3>
                            <div className="status-indicator">
                                <div className="status-dot"></div>
                                <span>Verified Intelligence</span>
                            </div>
                        </div>
                        {/* SESSION TOOLBAR */}
                        <div className="grid-selector">
                             <button className="icon-btn" title="New Chat" onClick={handleNewSession}><PlusIcon /></button>
                             <button className="icon-btn" title="History" onClick={() => setDrawerState({isOpen: true, mode: 'history', title: 'Session Archives', data: null})}><HistoryIcon /></button>
                             <button className="icon-btn" title="Save to Vault" onClick={() => setIsSaveModalOpen(true)}><SaveIcon /></button>
                             <button className="icon-btn" title="Clear Session" onClick={handleDeleteSession}><TrashIcon /></button>
                        </div>
                    </div>
                    {/* CONTEXT BAR */}
                    <ContextBar vaults={filteredVaults} sources={filteredSources} />
                    
                    <div className="chat-area" ref={chatScrollRef}>
                        {chatLog.map(msg => (
                            <ChatMessage 
                                key={msg.id} 
                                text={msg.text} 
                                isUser={msg.isUser} 
                                timestamp={msg.timestamp} 
                                groundingMetadata={msg.groundingMetadata}
                            />
                        ))}
                        {isLoading && (
                             <div className="chat-message mercury">
                                 <span className="chat-label mercury">MERCURY</span>
                                 <div className="analyzing-indicator">
                                     Analyzing sources...
                                 </div>
                             </div>
                        )}
                    </div>
                    <div className="chat-input-area">
                        <div className="chat-input-wrapper">
                            <input 
                                ref={inputRef}
                                type="text" 
                                value={inputValue}
                                onChange={handleInputChange}
                                onKeyDown={handleKeyDown}
                                placeholder="Request verified intelligence or Search URL..."
                                disabled={isLoading}
                            />
                            {/* Voice Button */}
                            <button className="voice-btn" title="Voice Mode">
                                <img 
                                    src="https://storage.googleapis.com/connexusai-assets/ICON_RAGbox2.png" 
                                    className="voice-icon-image"
                                    alt="Voice"
                                />
                            </button>
                            <button 
                                className="send-btn design-btn" 
                                title="Generate Design + Chat"
                                onClick={() => handleSendMessage('design')} 
                                disabled={isLoading || !inputValue.trim()}
                            >
                                <DesignGenIcon />
                            </button>
                        </div>
                        <div className="chat-footer-info">
                            Responses are citation-backed. Unverifiable outputs are withheld.
                        </div>
                    </div>
                </div>
                <div className="resizer" onMouseDown={() => handleMouseDown(2)}></div>

                {/* COLUMN 3: STUDIO */}
                <div className="panel studio-panel">
                    <div className="panel-header">
                        <div style={{display:'flex', gap: 8, alignItems:'center'}}>
                            <h3>Studio</h3>
                            {/* MODE SELECTOR */}
                            <div className="studio-mode-selector">
                                <button className={`mode-btn ${studioMode === 'UI' ? 'active' : ''}`} onClick={() => setStudioMode('UI')} title="UI Code">
                                    <LayoutIcon />
                                </button>
                                <button className={`mode-btn ${studioMode === 'ASSET' ? 'active' : ''}`} onClick={() => setStudioMode('ASSET')} title="Visual Asset">
                                    <ImageIcon />
                                </button>
                                <button className={`mode-btn ${studioMode === 'CHART' ? 'active' : ''}`} onClick={() => setStudioMode('CHART')} title="Data Viz">
                                    <ChartIcon />
                                </button>
                                <button className={`mode-btn ${studioMode === 'VISION' ? 'active' : ''}`} onClick={() => setStudioMode('VISION')} title="Vision-to-Code">
                                    <VisionIcon />
                                </button>
                                <button className={`mode-btn ${studioMode === 'VIDEO' ? 'active' : ''}`} onClick={() => setStudioMode('VIDEO')} title="Motion/Video">
                                    <VideoIcon />
                                </button>
                            </div>
                        </div>
                        <div className="panel-actions">
                            <div className="grid-selector">
                                <button 
                                    className={`icon-btn ${gridColumns === 1 ? 'active' : ''}`} 
                                    onClick={() => setGridColumns(1)}
                                    title="1 Column"
                                >
                                    <Layout1Icon />
                                </button>
                                <button 
                                    className={`icon-btn ${gridColumns === 2 ? 'active' : ''}`} 
                                    onClick={() => setGridColumns(2)}
                                    title="2 Columns"
                                >
                                    <Layout2Icon />
                                </button>
                                <button 
                                    className={`icon-btn ${gridColumns === 4 ? 'active' : ''}`} 
                                    onClick={() => setGridColumns(4)}
                                    title="4 Columns"
                                >
                                    <Layout4Icon />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className="studio-content">
                        {artifacts.length === 0 ? (
                            <div className="studio-empty">
                                <SparklesIcon />
                                <p>Studio Ready</p>
                                <span>Select a template to begin generation:</span>
                                <div className="studio-options-grid">
                                    {INITIAL_PLACEHOLDERS.map((ph, idx) => (
                                        <button 
                                            key={idx} 
                                            className="studio-option-btn"
                                            onClick={() => handleSendMessage('design', ph)}
                                        >
                                            {ph}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        ) : (
                            <div className={`studio-grid cols-${gridColumns}`}>
                                {artifacts.map((art, index) => (
                                    <div key={art.id} className="studio-item-wrapper">
                                        <ArtifactCard 
                                            artifact={art}
                                            isFocused={focusedArtifactIndex === index}
                                            onClick={() => {
                                                setFocusedArtifactIndex(index);
                                                if(art.type === 'ui' || art.type === 'chart') {
                                                    setDrawerState({ isOpen: true, mode: 'code', title: 'Source Code', data: art.content });
                                                }
                                            }}
                                        />
                                        <div className="studio-item-actions">
                                             {art.type === 'ui' && (
                                                <button onClick={() => handleGenerateVariations(art.id)} className="studio-action-btn">
                                                    <SparklesIcon /> Var
                                                </button>
                                             )}
                                             {(art.type === 'ui' || art.type === 'chart') && (
                                                <button onClick={() => setDrawerState({ isOpen: true, mode: 'code', title: 'Code', data: art.content })} className="studio-action-btn">
                                                    <CodeIcon /> Code
                                                </button>
                                             )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    </>
  );
}

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(<React.StrictMode><App /></React.StrictMode>);
}
